function hello(){
    return "hello";
}


export {hello}