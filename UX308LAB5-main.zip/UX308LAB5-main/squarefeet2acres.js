// This program *converts* **squarefeet** to **acres**

function squarefeet2acres(squarefeet){
    let acres = squarefeet/43560;
    return acres;
}

export {squarefeet2acres}